require('./dist/angular-nvd3');
module.exports = 'nvd3';